# Smart Folder Organizer

Smart Folder Organizer is a Python package that automatically organizes
files into categorized folders based on their file extensions.

## Features

- Organizes images
- Organizes PDF files
- Organizes documents
- Organizes spreadsheets
- Organizes presentations
- Organizes videos
- Organizes audio files
- Organizes archives
- Organizes source code
- Places unknown files in an Others folder
- Prevents overwriting existing files
- Supports dry-run mode

## Installation

```bash
pip install smart-folder-organizer-bertrand